<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/26
 * Time: 16:59
 */
namespace app\admin\controller;
use think\Db;
use think\Request;

class Admin extends Base{

    /*管理员设置*/
    public function adminlist(){
        $this->assign("list",$this->adminApi->getAdminList());
        $this->assign('username',input('username'));
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('type',input('type'));
        return $this->fetch();
    }

    public function adminadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['password'] = md5($data['pass']);
            $data['status'] = isset($data['status']) ? 1:0;
            $data['addtime'] = time();
            unset($data['pass']);
            unset($data['repass']);

            $name = $this->adminApi->where(['username'=>$data['username'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该账户名称",0);
            }

            $res = $this->adminApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("group_list",$this->adminGroupApi->select());
        return $this->fetch();
    }

    public function adminedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            if($data['pass']){
                $data['password'] = md5($data['pass']);
            }
            $data['status'] = isset($data['status']) ? 1:0;
            $data['endtime'] = time();
            unset($data['pass']);
            unset($data['repass']);

            $name = $this->adminApi->where(['username'=>$data['username'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该账户名称",0);
            }

            $res = $this->adminApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("data",$this->adminApi->getSingleAdminData(input("id")));
        $this->assign("group_list",$this->adminGroupApi->select());
        return $this->fetch();
    }

    public function admindel(){
        return $this->adminApi->delAdmin(input("id/a"));
    }

    public function adminajax(){
        $header = [
            ['id','管理员ID',10],
            ['username','登录名',20],
            ['nickname','昵称',20],
            ['title','角色',35],
            ['addtime','添加时间',35],
            ['last_login_time','最后一次登录时间',35],
            ['last_login_ip','最后一次登录ip',35],
            ["status",'状态'],
        ];
        $content = $this->adminApi->getAdminList(1);
        foreach ($content as $k =>$v) {
            if ($v['status'] == 1) {
                $content[$k]['status'] = '已启用';
            } else {
                $content[$k]['status'] = '已禁用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
        }
        exportExcel('管理员列表', $header, $content);//导出Excel
    }



    /*管理员角色设置*/
    public function grouplist(){
        $this->assign("list",$this->adminGroupApi->where(['is_del'=>1])->paginate());
        return $this->fetch();
    }

    public function groupadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['id_1']);
            unset($data['id_2']);
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['rules'] = $_POST['id'];

            $name = $this->adminGroupApi->where(['title'=>$data['title'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该角色名称",0);
            }

            $res = $this->adminGroupApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("authTree",$this->getAuthTree());
        return $this->fetch();
    }

    public function groupedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['id_1']);
            unset($data['id_2']);
            $data['status'] = isset($data['status']) ? 1:0;
            $data['rules'] = $_POST['id'];

            $name = $this->adminGroupApi->where(['title'=>$data['title'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该角色名称",0);
            }

            $res = $this->adminGroupApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("authTree",$this->getAuthTree());
        $this->assign("data",$this->adminGroupApi->find(input("id")));
        return $this->fetch();
    }

    public function groupdel(){
        return $this->adminGroupApi->del(input("id"));
    }

    public function groupajax(){
        $header = [
            ['id','ID',10],
            ['title','角色名	',20],
            ['description','描述',35],
            ["status",'状态'],
        ];
        $content = $this->adminGroupApi->select();
        foreach ($content as $k =>$v){
            if($v['status'] == 1){
                $content[$k]['status'] = '启用';
            }else {
                $content[$k]['status'] = '禁用';
            }
        }
        exportExcel('角色列表', $header, $content);//导出Excel
    }



    /*管理员权限设置*/
    public function authlist(){
        $name = input("name") ? input("name") : "";
        $strip = input("strip") ? input("strip") : "10";
        $type = input('type') ? input('type'): "";
        $condition = 'is_del=1 ';
        if($name){
            $condition = ' and name like "%'.$name.'%"';
        }
        if($type){
            if($type == 1){
                $condition .= ' and status = 1';
            }else{
                $condition .= ' and status != 1';
            }
        }
        $this->assign('name',input('name'));
        $this->assign('type',input('type'));
        $auth = $this->authRuleApi->where($condition)->paginate($strip,false,['query' => request()->param()]);
        foreach($auth as $k=>$v){
            $auth[$k]['top_name'] = $this->authRuleApi->where(['id'=>$v['top']])->value("name");
        }
        $this->assign("list",$auth);
        return $this->fetch();
    }

     public function authadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['status'] = isset($data['status']) ? 1:0;
            if($data['level'] == 1)
            {
                $data['top'] = 0;
            }

            $name = $this->authRuleApi->where(['name'=>$data['name'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该权限名称",0);
            }
            $url = $this->authRuleApi->where(['url'=>$data['url'],'is_del'=>1])->find();
            if($url){
                return ShowMsg("已有该权限连接",0);
            }

            $res = $this->authRuleApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        return $this->fetch();
    }

    public function authedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['status'] = isset($data['status']) ? 1:0;
            if($data['level'] == 1) {
                $data['top'] = 0;
            }

            $name = $this->authRuleApi->where(['name'=>$data['name'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该权限名称",0);
            }
            $url = $this->authRuleApi->where(['url'=>$data['url'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($url){
                return ShowMsg("已有该权限连接",0);
            }

            $res = $this->authRuleApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("data",$this->authRuleApi->find(input("id/a")));
        return $this->fetch();
    }

    public function authdel(){
        return $this->authRuleApi->del(input("id/a"));
    }

    public function authajax(){
        $name = input("name") ? input("name") : "";
        $type = input('type') ? input('type'): "";
        $condition = 'name like "%'.$name.'%"';
        if($type){
            if($type == 1){
                $condition .= ' and status = 1';
            }else{
                $condition .= ' and status != 1';
            }
        }
        $this->assign('name',input('name'));
        $this->assign('type',input('type'));
        $header = [
            ['id','ID',10],
            ['name','权限名称	',20],
            ['url','权限链接',35],
            ['top_name','所属上级权限名称',35],
            ["status",'是否显示'],
        ];
        $content = $this->authRuleApi->where($condition)->select();
        foreach ($content as $k =>$v){
            if($v['status'] == 1){
                $content[$k]['status'] = '显示';
            }else {
                $content[$k]['status'] = '隐藏';
            }
            $content[$k]['top_name'] = $this->authRuleApi->where(['id'=>$v['top']])->value("name");
        }
        exportExcel('管理员列表', $header, $content);//导出Excel
    }


    public function change_password(){
        if(Request::instance()->isAjax()){
            $data = json_decode(input("data"),true);
            if($data['old_password'] && $data['new_password'] && $data['re_password'] && $data['re_password'] == $data['new_password']){
                if(md5($data['old_password']) == session("admin_user.password")){
                    $res = $this->adminApi->where("id",session("admin_user.id"))->setField("password",md5($data['new_password']));
                    if($res !== false){
                        return true;
                    }else{
                        return false;
                    }
                }
            }else{
                return false;
            }
        }
        return $this->fetch();
    }


}