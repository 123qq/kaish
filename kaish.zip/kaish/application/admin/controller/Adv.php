<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 17:44
 */
namespace app\admin\controller;
use think\Request;
use think\Db;
class Adv extends Base{

    /*广告列表*/
    public function advlist(){
        $title = input("title") ? input("title") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'name' => array('like','%'.$title.'%'),
        ];
        $condition['addtime'] = ['between' , [$begintrade,$endtrade]];
        $this->assign("list",$this->advApi->where($condition)->order("id desc")->paginate($strip,false,['query' => request()->param()]));
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('title',input('title'));
        $this->assign('ptype',input('ptype'));
        return $this->fetch();
    }

    public function advadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//。。。。
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['addtime'] = time();

            $name = $this->advApi->where(['name'=>$data['name']])->find();
            if($name){
                return ShowMsg("已有该广告名称",0);
            }

            $res = $this->advApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        return $this->fetch();
    }

    public function advedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//...
            $data['status'] = isset($data['status']) ? 1 : 0;

            $name = $this->advApi->where(['name'=>$data['name'],'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该广告名称",0);
            }

            $res = $this->advApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $id = input("id") ? input("id") : 0;
        $data = $this->advApi->find($id);
        $this->assign("data",$data);
        return $this->fetch();
    }

    public function advdel(){
        return $this->advApi->delAdv(input("id/a"));
    }


    public function advajax(){
        $title = input("title") ? input("title") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'name' => array('like','%'.$title.'%'),
        ];
        if(input("language")){
            $condition['type'] = input("language");
        }
        $condition['addtime'] = ['between' , [$begintrade,$endtrade]];
        $content = $this->advApi->where($condition)->order("id desc")->select();
        $header = [
            ['id','ID',10],
            ["name",'图片名称',20],
            ["url",'图片链接',20],
            ["position",'位置',20],
            ["sort",'排序',300],
            ["addtime",'添加时间',30],
            ["status",'状态',30],
        ];
        foreach ($content as $k =>$v) {
            if ($v['status'] == 1) {
                $content[$k]['status'] = '已启用';
            } else {
                $content[$k]['status'] = '已禁用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
        }
        exportExcel('广告列表', $header, $content);//导出Excel
    }

}