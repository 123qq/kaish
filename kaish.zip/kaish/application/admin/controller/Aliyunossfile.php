<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/13
 * Time: 17:34
 */
namespace app\admin\controller;
use think\Controller;
use think\Request;
use OSS\OssClient;
use OSS\Core\OssException;
use think\Image;
use think\Config;

/**
 * 主要用于图片和富文本编辑的图片上传
 * Class File
 * @package app\admin\controller
 */
class Aliyunossfile extends Controller{


    /* OSS图片上传
    * liwei
    * */
    public function oss_uploadImage()
    {
        if (request()->has('base64', 'post')) {
            $data = $_POST['base64'];
            $result = $this->new_base64_upload($data);
            if ($result['code'] === 200) {
                $fileResult = &$result['data'];
                $filePath = $fileResult['path'] . $fileResult['name'];
                $ossFileName = implode('/', ['user/video', date('Ymd'), $fileResult['name']]);
                try {
                    //实例化对象 将配置传入
                    $ossClient = new OssClient(GetConf('zhCONF.aliyun_ak'),GetConf('zhCONF.aliyun_sk'),"oss-cn-beijing.aliyuncs.com");
                    $result = $ossClient->uploadFile(GetConf('zhCONF.aliyun_bucket'), $ossFileName, $filePath);
                    $arr = [
                        'oss_url' => $result['info']['url'],  //上传资源地址
                        'relative_path' => $ossFileName     //数据库保存名称(相对路径)
                    ];
                } catch (OssException $e) {
                    return $e->getMessage();
                } finally {
                    unlink($filePath);
                }
                return ShowMsg("上传成功",0,['src'=>$arr['oss_url']]);
            }
            return ShowMsg($result['msg']);
        } else {
            /*获取到上传的文件*/
            //$file = request()->file('file');
            $file = $_FILES['file'];
            if ($file) {
                $name = $file['name'];
                $format = strrchr($name, '.');//截取文件后缀名如 (.jpg)
                /*判断图片格式*/
                $allow_type = ['.jpg', '.jpeg', '.gif', '.bmp', '.png'];
                if (!in_array($format, $allow_type)) {
                    return ShowMsg("文件格式不在允许范围内哦");

                }
                // 尝试执行
                try {
                    //实例化对象 将配置传入
                    $ossClient = new OssClient(GetConf('zhCONF.aliyun_ak'),GetConf('zhCONF.aliyun_sk'),"oss-cn-beijing.aliyuncs.com");
                    //这里是有sha1加密 生成文件名 之后连接上后缀
                    $fileName = 'user/video/' . date("Ymd") . '/' . sha1(date('YmdHis', time()) . uniqid()) . $format;
                    //执行阿里云上传
                    $result = $ossClient->uploadFile(GetConf('zhCONF.aliyun_bucket'), $fileName, $file['tmp_name']);
                    /*组合返回数据*/
                    $arr = [
                        'oss_url' => $result['info']['url'],  //上传资源地址
                        'relative_path' => $fileName     //数据库保存名称(相对路径)
                    ];
                } catch (OssException $e) {
                    return $e->getMessage();
                }
                //将结果返回
                return ShowMsg("上传成功",0,['src'=>$arr['oss_url']]);
            }
            return ShowMsg("文件不存在");
        }
    }

    /**
     * 将Base64数据转换成二进制并存储到指定路径
     * @param        $base64
     * @param string $path
     * liwei
     * @return array
     */
    public function new_base64_upload($base64, $path = '') {
        $data = explode(',',$base64);
        trace($data,'api');
        unset($base64);
        if (count($data) !== 2){
            return['code'=>400,'msg'=>'文件格式错误'];
        }
        if (preg_match('/^(data:\s*image\/(\w+);base64)/', $data[0], $result)){
            $type = $result[2];
            if(!in_array($type,array('jpeg','jpg','gif','bmp','png'))){
                return['code'=>400,'msg'=>'文件格式不在允许范围内'];
            }
            $image_name = md5(uniqid()).'.'.$result[2];
            $image_path = "./upload/posts/";
            $image_file = $image_path . $image_name;
            //服务器文件存储路径
            try {
                if (file_put_contents($image_file, base64_decode($data[1]))) {
                    return['code'=>200, 'msg'=>'成功', 'data'=>['name' => $image_name, 'path' => $image_path]];
                } else {
                    return['code'=>400,'msg'=> '文件保存失败'];
                }
            }catch (\Exception $e){
                $msg = $e->getMessage();
                return['code'=>400,'msg'=>$msg];
            }
        }
        return['code'=>400,'msg'=>'文件格式错误'];
    }






}