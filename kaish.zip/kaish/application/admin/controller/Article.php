<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/16
 * Time: 13:46
 */
namespace app\admin\controller;
use org\Translate;
use think\Db;
use think\Request;

class Article extends Base{

    /*文章列表置*/
    public function articlelist(){
        $data = $this->articleApi->getArticleList();
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('title',input('title'));
        $this->assign("type_list",$this->articleTypeApi->field("id,title")->select());
        $this->assign("list",$data);
        $type = '';
        if(input('type_id')) $type = $this->articleTypeApi->where(['id'=>input('type_id')])->value('title');
        $this->assign('type',$type);
        $this->assign('type_id',input('type_id'));
        return $this->fetch();
    }

    public function articleadd()
    {
        if (Request::instance()->isAjax()) {
            $t = new Translate();
            $data = json_decode($_POST['data'], true);
            unset($data['file']);
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['adminid'] = session('admin_user.id');
            $data['addtime'] = time();

            $name = $this->articleApi->where(['title'=>$data['title'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该文章标题",0);
            }

            DB::startTrans();
            try {
                $res = $this->articleApi->insert($data);
                Db::commit();
                return ShowMsg("成功",1);
            } catch (\Exception $e) {
                Db::rollback();
                return ShowMsg("失败",0);
            }
        }
        $this->assign("cate", $this->articleTypeApi->field("id,title")->select());
        return $this->fetch();
    }

    public function articleedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['endtime'] = time();

            $name = $this->articleApi->where(['title'=>$data['title'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该文章标题",0);
            }

            $res = $this->articleApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $id = input("id") ? input("id") : 0;
        $data = $this->articleApi->find($id);
        $this->assign("data",$data);
        $this->assign("cate",$this->articleTypeApi->field("id,title")->select());
        return $this->fetch();
    }

    public function articledel(){
        return $this->articleApi->delArticle(input("id/a"));
    }

    public function articleajax(){
        $content = $this->articleApi->getArticleList(1);
        $header = [
            ['id','ID',10],
            ["username",'发布人',20],
            ["type_name",'文章类型',20],
            ["title",'文章标题',20],
            ['sketch','文章简介',200],
            ["sort",'排序',300],
            ["addtime",'添加时间',30],
            ["endtime",'修改时间',30],
            ["status",'状态',30],
        ];
        foreach ($content as $k =>$v) {
            if ($v['status'] == 1) {
                $content[$k]['status'] = '已启用';
            } else {
                $content[$k]['status'] = '已禁用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
            $content[$k]['endtime'] = format_time($v['endtime']);
        }
        exportExcel('文章列表', $header, $content);//导出Excel
    }

}