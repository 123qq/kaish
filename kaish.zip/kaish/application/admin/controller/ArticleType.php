<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 16:22
 */
namespace app\admin\controller;
use org\Translate;
use think\Request;

class ArticleType extends Base{

    /*文章分类列表*/

    public function typelist(){
        $list = $this->articleTypeApi->getArticleTypeList();
        foreach($list as $k=>$v){
            $list[$k]['top_name'] = $this->articleTypeApi->where(['id'=>$v['top']])->value("title");
        }
        $this->assign("list",$list);
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('title',input('title'));
        return $this->fetch();
    }

    public function typeadd(){
        if(Request::instance()->isAjax()){
            $t = new Translate();
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//...
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['level'] = $data['top'] == 0 ? 1:2;
            $data['addtime'] = time();

            $name = $this->articleTypeApi->where(['title'=>$data['title'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该文章类型标题",0);
            }

            $res = $this->articleTypeApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("top_cat",$this->articleTypeApi->getArticleTypeListByLevel());//文章顶级分类
        return $this->fetch();
    }

    public function typeedit(){
        if(Request::instance()->isAjax()){
            $t = new Translate();
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//...
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['level'] = isset($data['top']) ? 2 : 1;

            $name = $this->articleTypeApi->where(['title'=>$data['title'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该文章类型标题",0);
            }

            $res = $this->articleTypeApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("top_cat",$this->articleTypeApi->getArticleTypeListByLevel());//文章顶级分类
        $id = input("id") ? input("id") : 0;
        $this->assign("data",$this->articleTypeApi->find($id));
        return $this->fetch();
    }

    function typedel(){
        return $this->articleTypeApi->delArticleType(input("id/a"));
    }

    public function typeajax(){
        $content = $this->articleTypeApi->getArticleTypeList(1);
        foreach($content as $k=>$v){
            $content[$k]['top_name'] = $this->articleTypeApi->where(['id'=>$v['top']])->value("title");
        }
        $header = [
            ['id','ID',10],
            ['name','类型标识',20],
            ['title','标题',20],
            ['content','描述',20],
            ['top_name','上级分类名称',20],
            ['level','分类登等级',20],
            ['addtime','添加时间',30],
            ['sort','排序',10],
            ['status','状态',10],
        ];
        foreach ($content as $k=>$v){
            if($v['status']){
                $content[$k]['status'] = '已启用';
            }else{
                $content[$k]['status'] = '未启用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
        }
        exportExcel('文章分类', $header, $content);
    }

}