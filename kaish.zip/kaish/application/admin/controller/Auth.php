<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/13
 * Time: 11:25
 */
namespace app\admin\controller;
use think\Controller;
use think\Request;

class Auth extends Controller{

    public function __construct()
    {
        parent::__construct();
        $this->userApi=new \app\admin\model\User();
    }

    public function login(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $user_name = $data['username'];
            $password = $data['password'];
            return $this->userApi->doLogin($user_name,$password);
        }
        return $this->fetch();
    }
    public function logout(){
        $this->userApi->doLogout();
        $this->redirect("auth/login");
    }


    //检测权限
    public function verify()
    {
        $data = json_decode($_POST['data'],true);
        $id = $id ? $id : session("admin_user.id");
        if($id){

			$Admin = new Admin();
            $group = $Admin->where("id",$id)->value("group");
            $adminGroup = new adminGroup();
            $rules = $adminGroup->where("id",$group)->value("rules");
            $rules = explode(',', $rules);
          	if(in_array($data,$rules))
            {
                echo json_encode(1);
            }
            else
            {
                echo json_encode(0);
            }
        }
        else
        {
            echo json_encode(0);
        }


    }
}