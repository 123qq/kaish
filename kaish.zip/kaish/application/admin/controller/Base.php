<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/11
 * Time: 16:19
 */
namespace app\admin\controller;
use think\Controller;
use think\Request;

class Base extends Controller{
    /**
     * @var User
     */
    public $userApi;
    public $configApi;
    public $authRuleApi;
    public $worksApi;
    public $joinApi;
    public $articleApi;
    public $adminApi;
    public $adminGroupApi;
    public $navApi;
    public $worksTypeApi;
    public $articleTypeApi;
    public $userLogApi;
    public $userRoleApi;
    public $userCollecApi;
    public $userPraiseApi;
    public $userCommentApi;
    public $advApi;
    public function __construct()
    {
        parent::__construct();
        $this->userApi=new \app\admin\model\User();
        $this->configApi = new \app\admin\model\Config();
        $this->authRuleApi = new \app\admin\model\AuthRule();
        $this->worksApi = new \app\admin\model\Works();
        $this->joinApi = new \app\admin\model\Join();
        $this->articleApi = new \app\admin\model\Article();
        $this->adminApi = new \app\admin\model\Admin();
        $this->adminGroupApi = new \app\admin\model\AdminGroup();
        $this->navApi = new \app\admin\model\Nav();
        $this->worksTypeApi = new \app\admin\model\WorksType();
        $this->articleTypeApi = new \app\admin\model\ArticleType();
        $this->userLogApi = new \app\admin\model\UserLog();
        $this->userRoleApi = new \app\admin\model\UserRole();
        $this->userCollecApi = new \app\admin\model\UserCollec();
        $this->userPraiseApi = new \app\admin\model\UserPraise();
        $this->userCommentApi = new \app\admin\model\UserComment();
        $this->advApi = new \app\admin\model\Adv();
        $this->public_assign();
    }

    public function public_assign(){
        if(!$this->userApi->isLogin()){
            //不需要登录的方法和控制器，必须都满足才不用登录
            $noLoginController = ['System'];
            $noLoginMethod = ['auto','index'];
            if(!in_array(Request::instance()->action(),$noLoginMethod) || !in_array(Request::instance()->controller(),$noLoginController)){
//                $this->redirect("auth/login");
                $this->error('请登录',"auth/login");
            }
        }else{
            if(Request::instance()->controller()!="Index" && Request::instance()->controller()!="Auto"){
                if(!in_array(Request::instance()->controller().'/'.Request::instance()->action(),$_SESSION['think']['auth_array']['url'])){
                    $this->error('当前账户没有权限操作');
                }else{
                    execAdminLog();
                }
            }
        }

        $this->assign("web_name",$this->configApi->where("k","web_name")->value("v_zh"));
        $this->assign("admin_user",session("admin_user"));
        $this->assign("authTree",$this->getAuthTree(1));

        $this->assign("userAuthTree",$this->getUserAuth());
    }
    public function getAuthTree($status=null){
        if($status==1){
            $lv_1 = $this->authRuleApi->where(["status"=>1,"is_del"=>1,'level'=>1])->select();
            foreach($lv_1 as $k=>$v){
                $lv_1[$k]['son'] = $this->authRuleApi->where(["status"=>1,"is_del"=>1,'level'=>2,'top'=>$v['id']])->select();
            }
        }else {
            $lv_1 = $this->authRuleApi->where(["is_del" => 1, 'level' => 1])->select();
            foreach ($lv_1 as $k => $v) {
                $lv_1[$k]['son'] = $this->authRuleApi->where(["is_del" => 1, 'level' => 2, 'top' => $v['id']])->select();
            }
        }
        return $lv_1;
    }

    public function getUserAuth($id = ""){
        $id = $id ? $id : session("admin_user.id");
        if($id){
            $group = $this->adminApi->where(["id"=>$id,'is_del'=>1])->value("group");
            return $this->adminGroupApi->where(["id"=>$group,'is_del'=>1])->value("rules");
        }
    }
    //控制器中控制权限
    public function getAdminAuth($qid = ""){
        $id = $id ? $id : session("admin_user.id");
        if($id){
            $group = $this->adminApi->where(["id"=>$id,'is_del'=>1])->value("group");
            $rules = $this->adminGroupApi->where(["id"=>$group,'is_del'=>1])->value("rules");
            $rules = explode(',', $rules);
            if(in_array($qid,$rules)){
                return 1;
            }else{
                return 0;
            }
        }else{
             return 0;
        }
    }
    public function check_arr($rs){
        foreach ($rs as $v) {
            if (!$v) {
                return false;
            }
        }
        return true;
    }
    
}