<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/13
 * Time: 16:21
 */
namespace app\admin\controller;
use org\Translate;
use think\Db;
use think\Request;
use think\Controller;
use think\Loader;

class Config extends Base{

    /**
     * 基本配置
     */
    public function basic(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//不知道为什么有个file..
            $this->configApi->saveConfig($data);
            return true;
        }
        $emp=$this->configApi->column("k,v_zh,v_en");
        $this->assign("config",$emp);
        return $this->fetch();
    }

    /**
     * 短信配置
     */
    public function smsconfig(){

//        $number = "17082170787";//input('number');//input助手函数	获取输入数据 支持默认值和过滤
//        Loader::import('aliyunsms.api_demo.SmsDemo',EXTEND_PATH);//对应extend目录，路径，如果你对SmsDemo类添加了命名空间可在上面 use 后在此处直接实例化
//        $code = random();
//        //得到信息文件并执行.实例化阿里短信类
//        $msg = new \SmsDemo();//注意类名前面的  \ 此处写的就是Access key id 和Access key secret
//        //此配置在sdk包中有相关例子
//        $res = $msg->sendSms(
//            //短信模板code
//            "SMS_168340963",//此处填写你在阿里云平台配置的短信模板code（第二步有说明）
//            //短信接收者的手机号码
//            " $number",
//            //模板信息
//            Array(
//                'code' => $code,//随机变化的
//            )
//        );
//        dump($res);die;


        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $this->configApi->saveConfig($data);
            return true;
        }
        $this->assign("config",$this->configApi->where("k","like","sms%")->column("k,v_zh,v_en"));
        return $this->fetch();
    }

    /**
     * 客服配置
     */
    public function customerconfig(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);//不知道为什么又有个file..
            $this->configApi->saveConfig($data);
            return true;
        }
        $this->assign("config",$this->configApi->where("k","like","contact%")->column("k,v_zh,v_en"));
        return $this->fetch();
    }

    /**
     * 邮箱设置
     */
    public function mailconfig(){

//        $a = SendMailsss("3165418574@qq.com","标题","内容","");
//        print_r($a);die;
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['mailAuth'] = isset($data['mailAuth']) ? 'true' : 'false';
            $this->configApi->saveConfig($data);
            return true;
        }
        $this->assign("config",$this->configApi->where("k","like","mail%")->column("k,v_zh,v_en"));
        return $this->fetch();
    }

    /**
     * 七牛云设置
     */
    public function qiniu(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $this->configApi->saveConfig($data);
            return true;
        }
        $qn = Db::name('config_vip')->where('k','in','qn_bucket,qn_ak,qn_sk,qn_thechain,qn_address')->column("k,v_zh,v_en");
        $this->assign('qn',$qn);
        return $this->fetch();
    }

    /**
     * 阿里云设置
     */
    public function aliyun(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $this->configApi->saveConfig($data);
            return true;
        }
        $aliyun = Db::name('config_vip')->where('k','in','aliyun_bucket,aliyun_ak,aliyun_sk')->column("k,v_zh,v_en");
        $this->assign('aliyun',$aliyun);
        return $this->fetch();
    }



    /**
     * 导航设置
     */
    public function navconfig(){
        $title = input("title") ? input("title") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "0";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";
        $condition = 'is_del=1 and (addtime >= '. $begintrade .' and addtime <=' .$endtrade.')' ;
        if($title){
            $condition .= ' and (title_zh like "%'.$title.'%" or title_en like "%'.$title.'%")';
        }

        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('title',input('title'));
        $this->assign("list",$this->navApi
            ->where($condition)
            ->order("sort asc,id desc")
            ->paginate($strip,false,['query' => request()->param()]));
        return $this->fetch();
    }

    public function navedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['endtime'] = time();

            $name = $this->navApi->where(['name'=>$data['name'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该导航标题",0);
            }

            $res = $this->navApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("data",$this->navApi->find(input("id")));
        return $this->fetch('navEdit');
    }

    public function navadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $data['status'] = isset($data['status']) ? 1 : 0;
            $data['addtime'] = time();

            $name = $this->navApi->where(['title_zh'=>$data['title_zh'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该导航标题",0);
            }

            $res = $this->navApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        return $this->fetch();
    }

    public function navdel(){
        return $this->navApi->delNav(input("id/a"));
    }

    public function navajax(){
        $header = [
            ['id','导航ID',10],
            ['name','连接名称',50],
            ['title_zh','标题',50],
            ['url','链接地址',50],
            ['addtime','添加时间',35],
            ["status",'状态'],
        ];

        $title = input("title") ? input("title") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "0";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $condition = ' addtime >= '. $begintrade .' and addtime <=' .$endtrade;
        if($title){
            $condition .= ' and title_zh like "%'.$title.'%"';
        }
        $content = $this->navApi
            ->where($condition)
            ->order("id desc")
            ->select();

        foreach ($content as $k =>$v) {
            if ($v['status'] == 1) {
                $content[$k]['status'] = '已启用';
            } else {
                $content[$k]['status'] = '已禁用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
        }
        exportExcel('导航列表', $header, $content);//导出Excel
    }



}