<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/13
 * Time: 17:34
 */
namespace app\admin\controller;
use think\Controller;
use think\Request;
use Qiniu\Auth;
use Qiniu\Storage\BucketManager;
use Qiniu\Storage\UploadManager;
/**
 * 主要用于图片和富文本编辑的图片上传
 * Class File
 * @package app\admin\controller
 */
class File extends Controller{
    public function upload(){
        $file = Request::instance()->file("file");
        $filePath = $file->getRealPath();
        $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
        $token=$this->getToken();
        $uploadManager=new UploadManager();
        $key ='sb'.substr(md5($filePath) , 0, 5). date('YmdHis') . rand(0, 9999) . '.' . $ext;
        list($ret,$err)=$uploadManager->putFile($token,$key,$filePath);
        if($ret !==null){
            return ShowMsg("上传成功",0,['src'=>GetConf('zhCONF.qn_thechain')."/".$key]);
        }else{
            return ShowMsg($file->getError());
        }


        // 上传本地
        /* $info = $file -> move(ROOT_PATH.'upload'.DS.'web');
         if($info){
             return ShowMsg("上传成功",0,['src'=>'/upload'.DS.'web'.DS.$info->getSaveName()]);
         }else{
             return ShowMsg($file->getError());
         }*/
    }

    /**
     * 七牛上传凭证
     * @return array|string
     */
    public function getToken(){
            $accessKey = GetConf('zhCONF.qn_ak');
            $secretKey = GetConf('zhCONF.qn_sk');
            $bucket = GetConf('zhCONF.qn_bucket');
            $auth = new Auth($accessKey, $secretKey);
            //生成上传token
            $token = $auth->uploadToken($bucket);
            return $token;

    }


    public function uploads(){
        $file = Request::instance()->file("file");
        $filePath = $file->getRealPath();
        $arr = getimagesize($filePath);
        if($arr[0]>500 || $arr[1]>500 || abs($arr[0]-$arr[1])>5) return ShowMsg('请保证图片宽高一致');
        $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
        $token=$this->getToken();
        $uploadManager=new UploadManager();
        $key ='ht'.substr(md5($filePath) , 0, 5). date('YmdHis') . rand(0, 9999) . '.' . $ext;
        list($ret,$err)=$uploadManager->putFile($token,$key,$filePath);
        if($ret !==null){
            return ShowMsg("上传成功",0,['src'=>GetConf('zhCONF.qn_thechain')."/".$key]);
        }else{
            return ShowMsg($file->getError());
        }


        // 上传本地
        /* $info = $file -> move(ROOT_PATH.'upload'.DS.'web');
         if($info){
             return ShowMsg("上传成功",0,['src'=>'/upload'.DS.'web'.DS.$info->getSaveName()]);
         }else{
             return ShowMsg($file->getError());
         }*/
    }

}