<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/11
 * Time: 16:19
 */
namespace app\admin\controller;
class Index extends Base{
    public function __construct()
    {
        parent::__construct();
    }
    public function index(){
        return $this->fetch();
    }
    public function welcome(){
        $data = $this->userApi->getLastMonthRegData();
        if($data) {
            foreach ($data as $v){
                $reg_data['date'] []= $v['gap'];
                $reg_data['num'] []= $v['num'];
            }
            $this->assign("reg_data",json_encode($reg_data));//注册趋势
        }else{
            $this->assign("reg_data",0);//注册趋势
        }


        $this->assign("server_info",get_server_info());//服务器信息
        $this->assign("works_total",$this->worksApi->getWorksNum());//作品总量
        $this->assign("join_total",$this->joinApi->getJoinNum());//合作总数
        $this->assign("user_total",$this->userApi->getUserNum());//用户总数
        $this->assign("article_total",$this->articleApi->getArticleNum());//文章总数
        return $this->fetch();
    }
}