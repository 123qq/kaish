<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/11
 * Time: 16:26
 */
namespace app\admin\controller;
use think\Controller;
use org\Translate;
use think\Db;
use think\Request;
use think\Loader;
class Join extends Base{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 合作交流列表
     * Powered by: 李松大帅哥
     * @return mixed
     */
    public function joinlist(){
        $this->assign("list",$this->joinApi->getJoinList());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function joinlists(){
        $this->assign("list",$this->joinApi->getJoinLists());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function joinadd()
    {
        if (Request::instance()->isAjax()) {
            $t = new Translate();
            $data = json_decode($_POST['data'], true);
            unset($data['file']);
            $data['createtime'] = date('Y-m-d H:i:s',time());

            $name = $this->joinApi->where(['title'=>$data['title'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该标题",0);
            }

            DB::startTrans();
            try {
                $res = $this->joinApi->insert($data);
                Db::commit();
                return ShowMsg("成功",1);
            } catch (\Exception $e) {
                Db::rollback();
                return ShowMsg("失败",0);
            }
        }
        $this->assign("class_id",$this->worksTypeApi->field("id,name")->where(['is_del'=>1])->select());
            $user = $this->userApi->field("id,username,nickname")->where(['is_del'=>1])->select();
        $this->assign("user",$user);
        $this->assign("top",$this->joinApi->field("id,title")->where(['top'=>0,'is_del'=>1])->select());
        return $this->fetch();
    }

    public function joinedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            unset($data['file']);
            $data['updatetime'] = date('Y-m-d H:i:s',time());

            $name = $this->joinApi->where(['title'=>$data['title'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该标题",0);
            }

            $res = $this->joinApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $id = input("id") ? input("id") : 0;
        $data = $this->joinApi->find($id);
        $this->assign("data",$data);
        $this->assign("class_id",$this->worksTypeApi->field("id,name")->where(['is_del'=>1])->select());
        $user = $this->userApi->field("id,username,nickname")->where(['is_del'=>1])->select();
        $this->assign("user",$user);
        $this->assign("top",$this->joinApi->field("id,title")->where(['top'=>0,'is_del'=>1])->select());

        return $this->fetch();
    }

    public function joindel(){
        return $this->joinApi->delJoin(input("id/a"));
    }

    public function joinopen(){
        return $this->joinApi->openJoin(input("id"));
    }

    public function joinclose(){
        return $this->joinApi->closeJoin(input("id"));
    }

    public function joinselect(){
        $id = input("id");
        $num = input("num");
        $topclass = input("topclass");
        return $this->joinApi->getJoinSelect($id,$num,$topclass);
    }

    public function joinajax(){
        $content = $this->joinApi->getJoinLists(1);
        $header = [
            ['id','ID',10],
            ['username','作者账号',20],
            ['nickname','作者昵称',20],
            ['class_id','项目类型',20],
            ['top','上级项目',20],
            ['title','项目标题',40],
            ['introduce','项目介绍',300],
            ['collec_num','收藏数量',10],
            ['comment_num','评论数量',10],
            ['praise_num','点赞数量',10],
            ['createtime','添加时间',30],
            ['updatetime','编辑时间',30]
        ];
        exportExcel('合作项目列表', $header, $content);

    }

}