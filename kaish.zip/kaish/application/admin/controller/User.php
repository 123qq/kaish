<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/11
 * Time: 16:26
 */
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Loader;
class User extends Base{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * 会员列表
     * @param int $is_excel
     * @return mixed
     */
    public function userlist($is_excel = 0){
        $keywords = input("keywords") ? input("keywords") : "";
        $strip = input("strip") ? input("strip") : 10;
        $begintrade = input("begintrade") ? input("begintrade") : "";
        $endtrade = input("endtrade") ? input("endtrade") : '';
        $type = input("type") ? input("type") : '';
        $condition = 'a.is_del=1';
        if($type){
            if($type == 'id'){
                $condition .= " and a.$type = '" . $keywords . "'";
            }else{
                $condition .= " and a.$type like '" .'%'. $keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= ' and a.addtime >=' .  strtotime($begintrade);
        if($endtrade) $condition .= ' and a.addtime <= ' .  (strtotime($endtrade)+86340);
        $data = $this->userApi->alias('a')
            ->field("a.*,r.role as role_name")
            ->join('user_role r','a.role_id=r.id')
            ->where($condition)->order("a.id desc")->paginate($strip,false,[
            'query' => request()->param(),
        ]);
        $this->assign("list",$data);
        $this->assign('keywords',$keywords);
        $this->assign('begintrade',$begintrade);
        $this->assign('endtrade',$endtrade);
        $this->assign('type',$type);
        return $this->fetch();
     
    }

    public function useradd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $username = $data['username'] ? $data['username'] : "";
            $mobile = $data['mobile'] ? $data['mobile'] : "";
            $email = $data['email'] ? $data['email'] : "";
            $pwd = $data['pass'] ? $data['pass'] : "";
            return $this->userApi->addUser($username,$email,$mobile,$pwd);
        }
        return $this->fetch();
    }

    public function useredit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $id = $data["id"];
            $username = $data["username"] ? $data["username"] : "";
            $status = isset($data['status']) ? 1 : 0;
            $password = $data["pass"] ? $data["pass"] : "";
            $mobile = $data["mobile"] ? $data["mobile"] : "";
            $email = $data["email"] ? $data["email"] : "";
            $realname = $data["realname"] ? $data["realname"] : "";
            $nickname = $data["nickname"] ? $data["nickname"] : "";
            $role_id = $data["role_id"] ? $data["role_id"] : "";
            return $this->userApi->editUserData($id,$username,$password,$mobile,$email,$realname,$nickname,$status,$role_id);
        }
        $data = $this->userApi->getUserData(input("id"));
        $this->assign("data",$data);
        $this->assign("rolelist",$this->userRoleApi->getUserRoleList());
        return $this->fetch();
    }

    public function userdel(){
        return $this->userApi->delUser(input("id/a"));
    }

    public function useropen(){
        return $this->userApi->openUser(input("id/a"));
    }

    public function userclose(){
        return $this->userApi->closeUser(input("id/a"));
    }

    public  function userajax(){
        $header = [
            ['id','ID',10],
            ['username','帐号',20],
            ["mobile",'手机',20],
            ["email",'邮箱',20],
            ["nickname",'昵称',20],
            ["realname",'真实姓名',20],
            ["addtime",'注册时间',30],
            ["status",'状态'],
        ];
        $keywords = input("keywords") ? input("keywords") : "";
        $type = input("type") ? input("type") : '';
        $begintrade = input("begintrade") ? input("begintrade") : '';
        $endtrade = input("endtrade") ? input("endtrade") : '';
        $condition = 'is_del = 1';
        if($type){
            if($type == 'id'){
                $condition .= " and $type = '" . $keywords . "'";
            }else{
                $condition .= " and $type like '" .'%'. $keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= ' and addtime >=' .  strtotime($begintrade);
        if($endtrade) $condition .= ' and addtime <= ' .  (strtotime($endtrade)+86340);
        $content = $this->userApi
            ->where($condition)
            ->order("id desc")
            ->select();

        foreach($content as $k=>$v){
            if($v['status'] == 1){
                $content[$k]['status'] = '已启用';
            }else {
                $content[$k]['status'] = '已停用';
            }
            $content[$k]['addtime'] = format_time($v['addtime']);
        }

        exportExcel('会员列表', $header, $content);//导出Excel
    }


    /**
     * 会员角色列表
     * @param int $is_excel
     * @return mixed
     */
    public function rolelist(){
        $this->assign("list",$this->userRoleApi->getUserRoleList());
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();

    }

    public function roleadd(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $role = $data['role'] ? $data['role'] : "";
            return $this->userRoleApi->addRole($role);
        }
        return $this->fetch();
    }

    public function roleedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $id = $data["id"];
            $role = $data["role"] ? $data["role"] : "";
            return $this->userRoleApi->editRoleData($id,$role);
        }
        $data = $this->userRoleApi->getRoleData(input("id"));
        $this->assign("data",$data);
        return $this->fetch();
    }

    public function roledel(){
        $id = input("id/a");
        return $this->userRoleApi->delRole($id);
    }

    public  function roleajax(){
        $header = [
            ['id','ID',10],
            ['role','角色名称',20],
            ["createtime",'创建时间',30],
        ];
        $keywords = input("keywords") ? input("keywords") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("begintrade") ? input("begintrade") : "";
        $endtrade = input("endtrade") ? input("endtrade") : '';

        $condition = 'is_del = 1';
        $condition .= " and role like '".'%'.$keywords.'%'."'";
        if($begintrade) $condition .= " and createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        $content = $this->userRoleApi
            ->where($condition)
            ->order("id desc")
            ->select();
        exportExcel('会员角色列表', $header, $content);//导出Excel
    }


    /**
     * 用户日志
     * Powered by: 李松大帅哥
     * @return mixed
     */
    public function userloglist(){
        $this->assign("list",$this->userLogApi->getUserLogList());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function userlogajax(){
        $content = $this->userLogApi->getUserLogList(1);
        $header = [
            ['id','ID',10],
            ["username",'帐号',20],
            ["type",'类型',20],
            ["remark",'内容'],
            ["addip",'ip',30],
            ["addtime",'时间',30],

        ];
        foreach ($content as $k =>$v){
            $content[$k]['addtime'] = format_time($v['addtime']);
        }
        exportExcel('会员登录日志', $header, $content);//导出Excel
    }



    /**
     * 用户收藏列表
     * Powered by: 李松大帅哥
     * @return mixed
     */
    public function usercolleclist(){
        $this->assign("list",$this->userCollecApi->getUserCollecList());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function usercollectajax(){
        $content = $this->userCollecApi->getUserCollecList(1);
        $header = [
            ['id','ID',10],
            ["username",'用户帐号',20],
            ["nickname",'用户昵称',20],
            ["projectid",'项目标题',20],
            ["createtime",'收藏时间',30],
        ];
        exportExcel('会员收藏列表', $header, $content);//导出Excel
    }


    /**
     * 用户点赞列表
     * Powered by: 李松大帅哥
     * @return mixed
     */
    public function userpraiselist(){
        $this->assign("list",$this->userPraiseApi->getUserPraiseList());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function userpraiseajax(){
        $content = $this->userPraiseApi->getUserPraiseList(1);
        $header = [
            ['id','ID',10],
            ["username",'用户帐号',20],
            ["nickname",'用户昵称',20],
            ["projectid",'项目标题',20],
            ["createtime",'点赞时间',30],
        ];
        exportExcel('会员点赞列表', $header, $content);//导出Excel
    }


    /**
     * 用户评论列表
     * Powered by: 李松大帅哥
     * @return mixed
     */
    public function usercommentlist(){
        $this->assign("list",$this->userCommentApi->getUserCommentList());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function usercommentlists(){
        $this->assign("list",$this->userCommentApi->getUserCommentLists());
        $this->assign('start',input('start'));
        $this->assign('end',input('end'));
        $this->assign('type',input('type'));
        $this->assign('keywords',input('keywords'));
        $this->assign('username',input('username'));
        return $this->fetch();
    }

    public function opencomment(){
        return $this->userCommentApi->openComment(input("id"));
    }

    public function closecomment(){
        return $this->userCommentApi->closeComment(input("id"));
    }

    public function usercommentselect(){
        $id = input("id");
        $num = input("num");
        $topclass = input("topclass");
        return $this->userCommentApi->getUserCommentSelect($id,$num,$topclass);
    }

    public function usercommentajax(){
        $content = $this->userCommentApi->getUserCommentLists(1);
        $header = [
            ['id','ID',10],
            ["username",'用户帐号',20],
            ["nickname",'用户昵称',20],
            ["projectid",'项目标题',20],
            ["top",'上级评论id',20],
            ["content",'评论内容',300],
            ["createtime",'评论时间',30],
        ];
        exportExcel('会员评论列表', $header, $content);//导出Excel
    }


}