<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/16
 * Time: 13:46
 */
namespace app\admin\controller;
use org\Translate;
use think\Db;
use think\Request;

class Works extends Base{

    /*作品列表*/
    public function workslist(){
        $data = $this->worksApi->getWorksList();
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('title',input('title'));
        $this->assign("type_list",$this->worksTypeApi->field("id,name")->select());
        $this->assign("list",$data);
        $type = '';
        if(input('class_id')) $type = $this->worksTypeApi->where(['id'=>input('class_id')])->value('name');
        $this->assign('type',$type);
        $this->assign('class_id',input('class_id'));
        return $this->fetch();
    }

    public function worksadd()
    {
        if (Request::instance()->isAjax()) {
            $t = new Translate();
            $data = json_decode($_POST['data'], true);
            $participant = json_decode($_POST['participant'],true);
            if($participant){
                $participant_true = "";
                foreach($participant as $k=>$v){
                    $participant_true .= $v['value'].',';
                }
                $data['participant'] = $participant_true;
            }
            unset($data['file']);
            $data['createtime'] = date('Y-m-d H:i:s',time());

            $name = $this->worksApi->where(['title'=>$data['title'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该标题",0);
            }

            DB::startTrans();
            try {
                $res = $this->worksApi->insert($data);
                Db::commit();
                return ShowMsg("成功",1);
            } catch (\Exception $e) {
                Db::rollback();
                return ShowMsg("失败",0);
            }
        }
        $this->assign("class_id",$this->worksTypeApi->field("id,name")->where(['is_del'=>1])->select());
        $user = $this->userApi->field("id,username,nickname")->where(['is_del'=>1])->select();
        $this->assign("user",$user);

        //穿梭框全部用户
        $userarray = "";
        foreach($user as $k=>$v){
            $userarray .= "{'value': '".$v['id']."', 'title': '".$v['username']."（".$v['nickname']."）'},";
        }
        $this->assign("userarray",$userarray);

        return $this->fetch();
    }

    public function worksedit(){
        if(Request::instance()->isAjax()){
            $data = json_decode($_POST['data'],true);
            $participant = json_decode($_POST['participant'],true);
            if($participant){
                $participant_true = "";
                foreach($participant as $k=>$v){
                    $participant_true .= $v['value'].',';
                }
                $data['participant'] = $participant_true;
            }
            unset($data['file']);
            $data['updatetime'] = date('Y-m-d H:i:s',time());

            $name = $this->worksApi->where(['title'=>$data['title'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该标题",0);
            }

            $res = $this->worksApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $id = input("id") ? input("id") : 0;
        $data = $this->worksApi->find($id);
        $this->assign("data",$data);
        $this->assign("class_id",$this->worksTypeApi->field("id,name")->where(['is_del'=>1])->select());
        $user = $this->userApi->field("id,username,nickname")->where(['is_del'=>1])->select();
        $this->assign("user",$user);

        //穿梭框全部用户
        $userarray = "";
        foreach($user as $k=>$v){
            $userarray .= "{'value': '".$v['id']."', 'title': '".$v['username']."（".$v['nickname']."）'},";
        }
        $this->assign("userarray",$userarray);
        $this->assign("participant",$data['participant']);

        return $this->fetch();
    }

    public function worksdel(){
        return $this->worksApi->delWorks(input("id/a"));
    }

    public function worksajax(){
        $content = $this->worksApi->getWorksList(1);
        $header = [
            ['id','ID',10],
            ['username','作者账号',20],
            ['nickname','作者昵称',20],
            ['name','作品类型',20],
            ['title','作品标题',40],
            ['introduce','作品介绍',300],
            ['collec_num','收藏数量',10],
            ['comment_num','评论数量',10],
            ['praise_num','点赞数量',10],
            ['createtime','添加时间',30],
            ['updatetime','编辑时间',30]
        ];
        exportExcel('作品列表', $header, $content);

    }

}