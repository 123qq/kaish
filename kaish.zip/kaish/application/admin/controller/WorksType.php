<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 16:22
 */
namespace app\admin\controller;
use org\Translate;
use think\Request;

class WorksType extends Base{

    /*作品列表*/
    public function typelist(){
        $this->assign("list",$this->worksTypeApi->getWorksTypeList());
        $this->assign('begintrade',input('begintrade'));
        $this->assign('endtrade',input('endtrade'));
        $this->assign('name',input('name'));
        return $this->fetch();
    }
    
    public function typeadd(){
        if(Request::instance()->isAjax()){
            $t = new Translate();
            $data = json_decode($_POST['data'],true);
            unset($data['file']);
            $data['level'] = $data['top'] == 0 ? 1:2;
            $data['createtime'] = date('Y-m-d H:i:s',time());

            $name = $this->worksTypeApi->where(['name'=>$data['name'],'is_del'=>1])->find();
            if($name){
                return ShowMsg("已有该分类名称",0);
            }

            $res = $this->worksTypeApi->insert($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("top_cat",$this->worksTypeApi->getWorksTypeListByLevel());//顶级分类
        return $this->fetch();
    }

    public function typeedit(){
        if(Request::instance()->isAjax()){
            $t = new Translate();
            $data = json_decode($_POST['data'],true);
            unset($data['file']);
            $data['level'] = isset($data['top']) ? 2 : 1;

            $name = $this->worksTypeApi->where(['name'=>$data['name'],'is_del'=>1,'id'=>['neq',$data['id']]])->find();
            if($name){
                return ShowMsg("已有该分类名称",0);
            }

            $res = $this->worksTypeApi->where("id",$data['id'])->update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
        $this->assign("top_cat",$this->worksTypeApi->getWorksTypeListByLevel());//顶级分类
        $id = input("id") ? input("id") : 0;
        $this->assign("data",$this->worksTypeApi->find($id));
        return $this->fetch();
    }

    function typedel(){
        return $this->worksTypeApi->delWorksType(input("id/a"));
    }

    public function typeajax(){
        $content = $this->worksTypeApi->getWorksTypeList(1);
        $header = [
            ['id','ID',10],
            ['name','分类名称',20],
            ['level','分类级别',20],
            ['top','上级分类',30],
            ['createtime','添加时间',30],
        ];
        exportExcel('作品分类列表', $header, $content);
    }

}