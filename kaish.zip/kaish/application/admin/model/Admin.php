<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/26
 * Time: 16:56
 */
namespace app\admin\model;
use think\Model;
class Admin extends Model{
    public function getAdminList($is_ajax = NULL){
        $username = input("username") ? input("username") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "0";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";

        $condition = 'a.is_del=1 ';
        if($username){
            $condition = ' and a.username like "%'.$username.'%"';
        }
        $condition .= ' and a.addtime >= '.$begintrade.' and a.addtime <= '.$endtrade;

        if($type = input('type')){
            if($type == 1){
                $condition .= ' and a.status = 1';
            }else{
                $condition .= ' and a.status != 1';
            }
        }
        if($is_ajax){
            return $this
                ->alias('a')
                ->field('a.*,g.title')
                ->join('auth_group g','a.group=g.id')
                ->where($condition)
                ->order("id")
                ->select();
        }else{
            return $this
                ->alias('a')
                ->field('a.*,g.title')
                ->join('auth_group g','a.group=g.id')
                ->where($condition)
                ->order("id")
                ->paginate($strip,false,['query' => request()->param()]);
        }

    }
    public function getSingleAdminData($id){
        return $this
            ->alias('a')
            ->field('a.*,g.title')
            ->join('auth_group g','a.group=g.id')
            ->where("a.id",$id)
            ->order("id")
            ->find();
    }
    public function delAdmin($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
}