<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/11/9
 * Time: 16:31
 */
namespace app\admin\model;
use think\Model;
class AdminLog extends Model{
    public function getAllList($is_excel = 0){
        $admin_name = input("admin_name") ? input("admin_name") : "";
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'ad.username' => ['like',"%$admin_name%"],
        ];
        if(input("?type")){
            if(input("type")){
                $condition ['type'] = input("type");
            }
        }

        $type_arr = [
            '1'=>'登录',
            '2'=>'操作用户资金',
            '3'=>'查询',
            '4'=>'操作成功',
            '5'=>'操作失败'
        ];
        if($is_excel){
            $list =  $this
                ->alias('a')
                ->field("a.*,ad.username as admin_name")
                ->join("hs_admin ad","a.admin_id=ad.id")
                ->order("id desc")
                ->where($condition)
                ->select();
            foreach ($list as $k=>$v){
                $list[$k]['type'] = $type_arr[$v['type']];
            }
        }else{
            $list =  $this
                ->alias('a')
                ->field("a.*,ad.username as admin_name")
                ->join("hs_admin ad","a.admin_id=ad.id")
                ->order("id desc")
                ->where($condition)
                ->paginate($strip,false,['query'=>request()->param()]);
            foreach ($list as $k=>$v){
                $list[$k]['type'] = $type_arr[$v['type']];
            }
        }


        return $list;
    }
}