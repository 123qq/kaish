<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 17:46
 */
namespace app\admin\model;
use think\Model;
class Adv extends Model{
    public $table = "hs_adver";
    public function delAdv($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->delete();
        }else{
            $res = $this->where("id",$id)->delete();
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
}