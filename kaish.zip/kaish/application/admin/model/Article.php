<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/16
 * Time: 13:53
 */
namespace app\admin\model;
use think\Model;
class Article extends Model{
    public function getArticleList($is_ajax = NULL){
        $title = input("title") ? input("title") : "";
        $sketch = input("sketch") ? input("sketch") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'a.is_del' => 1,
            'a.title' => array('like','%'.$title.'%'),
            'a.sketch' => array('like','%'.$sketch.'%'),
        ];
        if(input("type_id")){
            $condition['a.type'] = input("type_id");
        }
        $condition['a.addtime'] = ['between' , [$begintrade,$endtrade]];
        if($is_ajax){
            return $this->alias("a")
                ->join("admin ad","a.adminid=ad.id")
                ->join("article_type at","a.type=at.id")
                ->field("a.*,ad.username,at.title as type_name")
                ->where($condition)
                ->order("sort asc")
                ->select();
        }
        return $this->alias("a")
            ->join("admin ad","a.adminid=ad.id")
            ->join("article_type at","a.type=at.id")
            ->field("a.*,ad.username,at.title as type_name")
            ->where($condition)
            ->order("sort asc")
            ->paginate($strip,false,['query' => request()->param()]);
    }
    public function getArticleNum(){
        return $this->count();
    }
    public function delArticle($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
}