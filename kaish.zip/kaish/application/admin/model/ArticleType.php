<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 15:43
 */
namespace app\admin\model;
use think\Model;
class ArticleType extends Model{
    public function getArticleTypeList($is_ajax = NULL){
        $title = input("title") ? input("title") : "";
        $begintrade = input("begintrade") ? strtotime(input("begintrade")) : "0";
        $endtrade = input("endtrade") ? (strtotime(input("endtrade"))+86340) : time();
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'is_del'=>1,
            'title' => array('like','%'.$title.'%'),
        ];
        $condition['addtime'] = ['between' , [$begintrade,$endtrade]];
        if($is_ajax){
            return $this
                ->where($condition)
                ->order("id desc")
                ->select();
        }
        return $this
            ->where($condition)
            ->order("id desc")
            ->paginate($strip,false,['query' => request()->param()]);
    }
    public function delArticleType($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function getArticleTypeListByLevel($level = '1'){
        return $this->where('level',$level)->select();
    }
}