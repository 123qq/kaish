<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/26
 * Time: 18:10
 */
namespace app\admin\model;
use think\Model;
class AuthRule extends Model{
    public $table = "hs_auth_rule";

    public function del($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
}