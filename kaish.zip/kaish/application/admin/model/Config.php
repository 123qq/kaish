<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/13
 * Time: 16:22
 */
namespace app\admin\model;
use org\Translate;
use think\Model;

class Config extends Model{
    public $table = 'hs_config_vip';
    public $needTranslate;//需要被翻译的k值数组，其他的K值直接存进数据库
    public $translate;
    public function __construct()
    {
        parent::__construct();
        $this->translate=new Translate();
        $this->needTranslate = ['LoginPrompt','refuseauth','invit_text_txt','mailxgPassword','mailauthentication','mailRegister','top_name','web_close_cause','web_description','web_icp','web_keywords','web_reg','web_title','web_waring','giftMoney','aggregate','recommend','marketStatus','marketSource','marketPercentage','machineStatus','machineSource','machinenum','macStatus','macEmp','macStart'];
    }

    public function saveConfig($data){

        foreach($data as $k=>$v){
            $this->where("k",$k)->setField("v_zh",$v);
            if(in_array($k,$this->needTranslate)){
                $this->where("k",$k)->setField("v_en",$this->translate->doTranslate($v,'zh','en'));
            }else{
                $this->where("k",$k)->setField("v_en",$v);
            }
            if($k == "aggregate"){
                $this->where("k",$k)->setField("v_en",$data['aggNum_1']);
            }
        }
    }
}