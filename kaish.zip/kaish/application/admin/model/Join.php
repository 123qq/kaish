<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/14
 * Time: 16:41
 */
namespace app\admin\model;
use think\Model;
class Join extends Model{
    public function getJoinList($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("start") ? input("start") : "";
        $endtrade = input("end") ? input("end") : '';
        $top = input("top") ? input("top") : '0';

        $condition = 'l.top = '.$top.' and l.is_del = 1';
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= " and l.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and l.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.user_id=u.id")
                ->field("l.*,u.username,u.nickname,u.mobile")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.user_id=u.id")
            ->field("l.*,u.username,u.nickname,u.mobile")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }

    public function getJoinLists($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("start") ? input("start") : "";
        $endtrade = input("end") ? input("end") : '';

        $condition = ' l.is_del = 1';
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= " and l.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and l.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.user_id=u.id")
                ->field("l.*,u.username,u.nickname,u.mobile")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.user_id=u.id")
            ->field("l.*,u.username,u.nickname,u.mobile,l.id as project")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }

    public function openJoin($id){
        $res = $this->where("id",$id)->setField("status",1);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function closeJoin($id){
        $res = $this->where("id",$id)->setField("status",0);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function getJoinSelect($id,$num,$topclass)
    {
        $num = intval($num) ? intval($num) : 1;
        $condition = 'l.top = ' . $id;
        $list =  $this
            ->alias("l")
            ->join("user u", "l.user_id=u.id")
            ->field("l.*,u.username,u.nickname,u.mobile,l.id as project")
            ->where($condition)
            ->order("l.createtime asc")
            ->select();

        $tr = "<tr class=' ".$topclass." class_".$id."'>";
        for($i=0;$i<$num;$i++){
            $tr .= "<th style='background-color: white;border:0px'></th>";
        }
        $tr .= "
            <th></th>
            <th>ID</th>
            <th>作者</th>
            <th>项目类型</th>
            <th>上级项目id</th>
            <th>项目标题</th>
            <th>项目介绍</th>
            <th>收藏数量</th>
            <th>评论数量</th>
            <th>点赞数量</th>
            <th>添加时间</th>
            <th>编辑时间</th>
            <th>状态</th>
            <th>操作</th>
        </tr>";
        foreach($list as $k => $v){
            $tr .="<tr class=' ".$topclass." class_".$id."'>";
            for($i=0;$i<$num;$i++){
                $tr .= "<td class='ww' style='background-color: white;border:0px'></td>";
            }
            $tr .= "<td class='ww' onclick='addTr(this,".$v['id'].",".($num+1).")' title='下级'><i class='layui-icon'>&#xe61a;</i></td>";
            $tr .= "<td class='ww'>".$v['id']."</td>";
            $tr .= "<td class='ww'>".$v['username']."（".$v['nickname']."）</td>";
            $tr .= "<td class='ww'>".$v['class_id']."</td>";
            $tr .= "<td class='ww'>".$v['top']."</td>";
            $tr .= "<td class='ww'>".$v['title']."</td>";
            $tr .= "<td class='ww'>".$v['introduce']."</td>";
            $tr .= "<td class='ww'>".$v['collec_num']."</td>";
            $tr .= "<td class='ww'>".$v['comment_num']."</td>";
            $tr .= "<td class='ww'>".$v['praise_num']."</td>";
            $tr .= "<td class='ww'>".$v['createtime']."</td>";
            $tr .= "<td class='ww'>".$v['updatetime']."</td>";

            $tr .= "<td class='td-status ww'><span class='layui-btn layui-btn-normal layui-btn-mini'>";
            if($v['status']==1){$tr .= "已显示";}else{ $tr .= "已隐藏";}
            $tr .= "</span></td>";

            $tr .= "<td class='td-manage'><a onclick='member_stop(this,".$v['id'].",52)' href='javascript:;' title='";
            if($v['status']==1){$tr .= "隐藏";}else{ $tr .= "显示";}
            $tr .= "'><i class='layui-icon'>";
            if($v['status']==1){$tr .= "<i class='layui-icon'>&#xe601;</i>";}else{$tr .= "<i class='layui-icon'>&#xe62f;</i>";}
            $tr .= "</a>";
            $tr .= "<a title='编辑' href=\"{:url('join/index',['id'=>".$v['id']."])}\"><i class='layui-icon'>&#xe642;</i></a>";
            $tr .= "<a title='删除' onclick=\"member_del(this,".$v['id'].")\" href='javascript:;'><i class='layui-icon'>&#xe640;</i></a>";
            $tr .= "</td>";
            $tr .= "</tr>";
        }
        if(count($list)<1){
            $tr ="<tr class=' ".$topclass." class_".$id."'>";
            for($i=0;$i<$num-1;$i++){
                $tr .= "<td class='ww' style='background-color: white;border:0px'></td>";
            }
            $tr .= "<td class='ww' colspan='14'>暂无数据展示</td>";
            $tr .= "</tr>";
        }
        return $tr;

    }

    public function delJoin($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 获取网站合作总数
     */
    public function getJoinNum(){
        return $this->count();
    }





}