<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/24
 * Time: 16:13
 */
namespace app\admin\model;
use think\Model;
class Nav extends Model{
    public $table = "hs_daohang";
    public function delNav($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
}