<?php
/**
 * Created by PhpStorm.
 * User: 李松
 * Date: 2017/10/11
 * Time: 16:21
 */
namespace app\admin\model;
use think\Db;
use think\Model;
class User extends Model{

    // 定义全局的查询范围
//    protected static function base($query){
//        $query -> where("hs_user.is_del",1);
//    }

    public function isLogin(){
        if(session("?admin_user")){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Powered by: 李松大帅哥
     * @param $username
     * @param $password
     * @return array
     * 执行登录操作
     */
    public function doLogin($username,$password){

        $data = Db::name("admin")->where(["username"=>$username,"password"=>md5($password),'is_del'=>1])->find();
        $time = time()-86400*30;
        Db::name('admin_log')->whereTime('create_time','<=',date('Y-m-d H:i:s',$time))->delete();

        if($data){
            $auth_arrays = Db::name("auth_rule")->field("url,name")->where(['is_del'=>1])->select();
            $auth_array = array_column($auth_arrays,'name','url');
            $auth_array['url'] = array_column($auth_arrays,'url');

            session("auth_array",$auth_array);
            session("admin_user",$data);
            runHook("Notify","adminLogin");
            return ShowMsg("登录成功",1);
        }else{
            return ShowMsg("登录失败，账号或密码错误",2);
        }
    }

    /**
     * Powered by: 李松大帅哥
     * 登出
     */
    public function doLogout(){
        session("admin_user",null);
        session("auth_array",null);
    }

    /**
     * 获取过去三十天网站注册数据
     */
    public function getLastMonthRegData(){
        $start_time =  strtotime("-30 days");
        $end_time = time();
        $data = Db::query("select COUNT(*) AS num,FROM_UNIXTIME(addtime,'%Y-%m-%d') as gap from hs_user WHERE addtime < $end_time AND addtime > $start_time group by gap");
        return $data;
    }

    /**
     * 获取网站用户总数
     */
    public function getUserNum(){
        return $this->count();
    }

    public function getUserData($id){
        return $this->find($id);
    }
    public function getUserToken($id){
        return $this->where("id",$id)->value("pwd_token");
    }

    /**
     * Powered by: 李松大帅哥
     * @param $id
     * @return bool
     * 删除用户（软删除而已，不删除资金记录）
     */
    public function delUser($id){
        Db::startTrans();
        try{
            if(is_array($id)){
                $res = $this->where("id","in",$id)->update(['is_del'=>0]);
            }else{
                $res = $this->where("id",$id)->update(['is_del'=>0]);
            }
            if($res !== false){
                Db::commit();
                return true;
            }else{
                Db::rollback();
                return false;
            }
        }catch (\Exception $e){
            Db::rollback();
            return false;
        }
    }
    public function closeUser($id){
        $res = $this->where("id",$id)->setField("status",0);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function openUser($id){
        $res = $this->where("id",$id)->setField("status",1);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function addUser($username = null,$email = null,$mobile = null,$password = null){
        $data = [];
        $data['addtime'] = time();
        if($username){
            $data['username'] = $username;
        }
        if($password){
            $data['password'] = md5($password.$data['pwd_token']);
        }
        if($mobile){
            $data['mobile'] = $mobile;
        }
        if($email){
            $data['email'] = $email;
        }

        $data_username = $this->field("*")->where("username='".$username."'")->find();
        $data_mobile = $this->field("*")->where("mobile='".$mobile."'")->find();
        $data_email = $this->field("*")->where("email='".$email."'")->find();
        if($data_username){
            return ShowMsg("账号已被注册，请填写其他账号",0);
        }else if($data_mobile){
            return ShowMsg("手机号已被注册，请填写其他手机号",0);
        }else if($data_email) {
            return ShowMsg("邮箱已被注册，请填写其他邮箱",0);
        }else {
            $res = $this->insert($data);
            if ($res !== false) {
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
    }
    public function editUserData($id,$username = null,$password = null,$mobile = null,$email = null,$realname = null,$nickname = null,$status=0,$role_id=0){
        $data = [];
        $is_update_mobile = false;
        if($username){
            $data['username'] = $username;
        }
        if($password){
            $data['password'] = md5($password.$this->getUserToken($id));
        }
        if($mobile){
            $data['mobile'] = $mobile;
            $old_mobile = $this->where(['id'=>$id])->value('mobile');
            if($mobile != $old_mobile) $is_update_mobile = true;
        }
        if($email){
            $data['email'] = $email;
        }
        if($realname){
            $data['realname'] = $realname;
        }
        if($nickname){
            $data['nickname'] = $nickname;
        }
        if($role_id){
            $data['role_id'] = $role_id;
        }
        $data['status'] = $status;

        $data_username = $this->field("*")->where("username='".$username."' and id<>'".$id."'")->find();
        $data_mobile = $this->field("*")->where("mobile='".$mobile."' and id<>'".$id."'")->find();
        $data_email = $this->field("*")->where("email='".$email."' and id<>'".$id."'")->find();
        if($data_username){
            return ShowMsg("账号已被注册，请填写其他账号",0);
        }else if($data_mobile){
            return ShowMsg("手机号已被注册，请填写其他手机号",0);
        }else if($data_email) {
            return ShowMsg("邮箱已被注册，请填写其他邮箱",0);
        }else{
            $res = $this -> where("id",$id) -> update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
    }
    public function getUserCertList($is_ajax = 0){
        $keywords = input("keywords") ? input("keywords") : "";
        $type = input('type') ? input('type') : "";
        $strip = input("strip") ? input("strip") :"10";
        $idcardauth = input("?idcardauth") ? input("idcardauth") : "";
        $condition = ['is_del'=> 1];
      
        if($type){
            if($type == "id"){
                $condition = [
                    'is_del'=> 1,
                    "$type" => $keywords,
                    'truename'=> ["neq",""],
                    'idcard'=> ["neq",""],
                    'idcardauth'=>["like","%$idcardauth%"],
                ];
            }else{
                $condition = [
                    'is_del'=> 1,
                    "$type" => ["like","%$keywords%"],
                    'truename'=> ["neq",""],
                    'idcard'=> ["neq",""],
                    'idcardauth'=>["like","%$idcardauth%"],
                ];
            }
        }
        if($is_ajax == 1){
            $data = $this
                ->where('truename',"<>",'')
                ->where($condition)
                ->order("id desc")
                ->select();
            return $data;
        }
        $data = $this
            ->where('truename',"<>",'')
            ->where($condition)
            ->order("id desc")
            ->paginate($strip,false,['query' => request()->param()]);
        return $data;
    }

    public function KaiShaDeciphering($s){
        $k = 13;
        //解密
        for($i=0; $i<strlen($s); $i++) {
            $n = ord($s{$i}) - $k;
            if($n < 32) $n = ($n - 32) & 0x7f;
            $s{$i} = chr($n);
        }
        return $s;
    }

    public function allUserPlat($is_ajax = NULL){
        $begintrade = input('begintrade') ? strtotime(input('begintrade')) : 0;
        $endtrade = input('endtrade') ? strtotime(input('endtrade'))+86399 : time();
        $keywords = input('keywords') ? input('keywords') : '';
        $type = input('type') ? input('type') : '';
        $strip = input("strip") ? input("strip") : "10";
        $where['c.addtime'] = ['between' , [$begintrade,$endtrade]];
        if($keywords){
            if($type == 'id'){
                $where["u.$type"] = $keywords;
            }else{
                $where["u.$type"] = array('like',"%$keywords%");
            }
        }
        $coin = input('coin') ? input('coin') : 'SSF';
        $name = $coin.'z';
        if($is_ajax){
            $user = $this->alias('u')
                ->join('user_coin uc','u.id = uc.userid')
                ->where(['u.seller' => 1])
                ->field("u.id,u.username,u.sort,uc.$name")
                ->select();
        }else{
            $user = $this->alias('u')
                ->join('user_coin uc','u.id = uc.userid')
                ->where(['u.seller' => 1])
                ->field("u.id,u.username,u.sort,uc.$name")
                ->paginate($strip,false,['query' => request()->param()]);
        }
        foreach ($user as $k=>$v){
            $user[$k]['first'] = $this->where('seller = 1 and sort <='.$v['sort'])->count();
        }
        return $user;
    }

    public function UserPlat(){
        $id = input('id');
        $coin = input('coin') ? input('coin') : 'SSF';
        $name = $coin.'z';
        $user = $this->alias('u')
            ->join('user_coin uc','u.id = uc.userid')
            ->where(['u.id' => $id])
            ->field("u.id,u.username,u.sort,uc.$name")
            ->find();
        return $user;
    }
    public function merchant($id){
        Db::startTrans();
        if(is_array($id)){
            $res = $this->where("id","in",$id)->setField("seller",1);
        }else{
            $res = $this->where("id",$id)->setField("seller",1);
        }
        if($res !== false){
            Db::commit();
            return true;
        }else{
            Db::rollback();
            return false;
        }
    }

    public function tracks($id){
        Db::startTrans();
        if(is_array($id)){
            $res = $this->where("id","in",$id)->setField("tracks",1);
        }else{
            $res = $this->where("id",$id)->setField("tracks",1);
        }
        if($res !== false){
            Db::commit();
            return true;
        }else{
            Db::rollback();
            return false;
        }
    }
}
