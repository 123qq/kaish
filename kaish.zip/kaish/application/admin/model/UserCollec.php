<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/14
 * Time: 16:41
 */
namespace app\admin\model;
use think\Db;
use think\Model;
class UserCollec extends Model{
    public function getUserCollecList($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("start") ? input("start") : "";
        $endtrade = input("end") ? input("end") : '';
        $w_projectid = input("w_projectid") ? input("w_projectid") : '';
        $j_projectid = input("j_projectid") ? input("j_projectid") : '';

        $condition = 'l.is_del = 1 ';
        if($w_projectid){
            $condition .= " and l.type=1 and w.id ='".$w_projectid."'";
        }
        if($j_projectid){
            $condition .= " and l.type=2 and j.id ='".$j_projectid."'";
        }
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else if($type == 'works'){
                $condition .= " and l.type=1 and w.title like '".'%'.$keywords.'%'."'";
            }else if($type == 'join'){
                $condition .= " and l.type=2 and j.title like '".'%'.$keywords.'%'."'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= " and l.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and l.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.userid=u.id")
                ->join("works w","l.projectid=w.id","left")
                ->join("join j","l.projectid=j.id","left")
                ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.userid=u.id")
            ->join("works w","l.projectid=w.id","left")
            ->join("join j","l.projectid=j.id","left")
            ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);

    }
}