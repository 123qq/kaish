<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/14
 * Time: 16:41
 */
namespace app\admin\model;
use think\Model;
class UserComment extends Model{
    public function getUserCommentList($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("start") ? input("start") : "";
        $endtrade = input("end") ? input("end") : '';
        $top = input("top") ? input("top") : '0';

        $w_projectid = input("w_projectid") ? input("w_projectid") : '';
        $j_projectid = input("j_projectid") ? input("j_projectid") : '';

        $condition = 'l.top = '.$top.' and l.is_del = 1';
        if($w_projectid){
            $condition .= " and l.type=1 and w.id ='".$w_projectid."'";
        }
        if($j_projectid){
            $condition .= " and l.type=2 and j.id ='".$j_projectid."'";
        }
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else if($type == 'content'){
                $condition .= " and l.$type like '".'%'.$keywords.'%'."'";
            }else if($type == 'works'){
                $condition .= " and l.type=1 and w.title like '".'%'.$keywords.'%'."'";
            }else if($type == 'join') {
                $condition .= " and l.type=2 and j.title like '" . '%' . $keywords . '%' . "'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }
        }

        if($begintrade) $condition .= " and l.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and l.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.userid=u.id")
                ->join("works w","l.projectid=w.id","left")
                ->join("join j","l.projectid=j.id","left")
                ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.userid=u.id")
            ->join("works w","l.projectid=w.id","left")
            ->join("join j","l.projectid=j.id","left")
            ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }

    public function getUserCommentLists($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("start") ? input("start") : "";
        $endtrade = input("end") ? input("end") : '';

        $condition = ' l.is_del = 1';
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else if($type == 'content'){
                $condition .= " and l.$type like '".'%'.$keywords.'%'."'";
            }else if($type == 'works'){
                $condition .= " and l.type=1 and w.title like '".'%'.$keywords.'%'."'";
            }else if($type == 'join') {
                $condition .= " and l.type=2 and j.title like '" . '%' . $keywords . '%' . "'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }
        }
        if($begintrade) $condition .= " and l.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and l.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.userid=u.id")
                ->join("works w","l.projectid=w.id","left")
                ->join("join j","l.projectid=j.id","left")
                ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.userid=u.id")
            ->join("works w","l.projectid=w.id","left")
            ->join("join j","l.projectid=j.id","left")
            ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }

    public function openComment($id){
        $res = $this->where("id",$id)->setField("status",1);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function closeComment($id){
        $res = $this->where("id",$id)->setField("status",0);
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function getUserCommentSelect($id,$num,$topclass)
    {
        $num = intval($num) ? intval($num) : 1;
        $condition = 'l.is_del=1 and l.top = ' . $id;
        $list =  $this
            ->alias("l")
            ->join("user u", "l.userid=u.id")
            ->join("works w","l.projectid=w.id","left")
            ->join("join j","l.projectid=j.id","left")
            ->field("l.*,u.username,u.nickname,u.mobile,w.title as w_title,j.title as j_title")
            ->where($condition)
            ->order("l.createtime asc")
            ->select();

        $tr = "<tr class=' ".$topclass." class_".$id."'>";
        for($i=0;$i<$num;$i++){
            $tr .= "<th style='background-color: white;border:0px'></th>";
        }
        $tr .= "
            <th></th>
            <th>ID</th>
            <th>用户账号</th>
            <th>项目名称</th>
            <th>项目类型</th>
            <th>上级评论id</th>
            <th>评论内容</th>
            <th>评论时间</th>
            <th>是否显示</th>
            <th>操作</th>
        </tr>";
        foreach($list as $k => $v){
            $tr .="<tr class=' ".$topclass." class_".$id."'>";
            for($i=0;$i<$num;$i++){
                $tr .= "<td class='ww' style='background-color: white;border:0px'></td>";
            }
            $tr .= "<td class='ww' onclick='addTr(this,".$v['id'].",".($num+1).")' title='下级'><i class='layui-icon'>&#xe61a;</i></td>";
            $tr .= "<td class='ww'>".$v['id']."</td>";
            $tr .= "<td class='ww'>".$v['username']."（".$v['nickname']."）</td>";


            if($v['type']==1){
                $tr .= "<td class='ww'>".$v['w_title']."</td>";
            }else if($v['type']==2){
                $tr .= "<td class='ww'>".$v['j_title']."</td>";
            }
            if($v['type']==1){
                $tr .= "<td class='ww'>作品</td>";
            }else if($v['type']==2){
                $tr .= "<td class='ww'>合作</td>";
            }

            $tr .= "<td class='ww'>".$v['top']."</td>";
            $tr .= "<td class='ww'>".$v['content']."</td>";
            $tr .= "<td class='ww'>".$v['createtime']."</td>";

            $tr .= "<td class='td-status ww'><span class='layui-btn layui-btn-normal layui-btn-mini'>";
            if($v['status']==1){$tr .= "已显示";}else{ $tr .= "已隐藏";}
            $tr .= "</span></td>";

            $tr .= "<td class='td-manage'><a onclick='member_stop(this,".$v['id'].",52)' href='javascript:;' title='";
            if($v['status']==1){$tr .= "隐藏";}else{ $tr .= "显示";}
            $tr .= "'><i class='layui-icon'>";
            if($v['status']==1){$tr .= "<i class='layui-icon'>&#xe601;</i>";}else{$tr .= "<i class='layui-icon'>&#xe62f;</i>";}
            $tr .= "</a></td>";

            $tr .= "</tr>";
        }
        if(count($list)<1){
            $tr ="<tr class=' ".$topclass." class_".$id."'>";
            for($i=0;$i<$num-1;$i++){
                $tr .= "<td class='ww' style='background-color: white;border:0px'></td>";
            }
            $tr .= "<td class='ww' colspan='9'>暂无数据展示</td>";
            $tr .= "</tr>";
        }
        return $tr;

    }





}