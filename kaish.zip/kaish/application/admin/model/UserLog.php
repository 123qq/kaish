<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/14
 * Time: 16:41
 */
namespace app\admin\model;
use think\Model;
class UserLog extends Model{
    public function getUserLogList($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $type = input("type") ? input("type") : '';
        $strip = input("strip") ? input("strip") : '10';
        $condition = 'u.is_del = 1';
        if($type){
            if($type == 'id'){
                $condition .= " and u.$type ='".$keywords."'";
            }else{
                $condition .= " and u.$type like '".'%'.$keywords.'%'."'";
            }

        }

        if(input("start") || input("end")){
            $start_time = input("start") ? strtotime(input("start")) : time();
            $end_time = input("end") ? (strtotime(input("end"))+86340) : time();
            $condition['l.addtime'] = ['between',[$start_time,$end_time]];
        }
        if($is_ajax == 1){
            return $this
                ->alias("l")
                ->join("user u","l.userid=u.id")
                ->field("l.*,u.username")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->join("user u","l.userid=u.id")
            ->field("l.*,u.username")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }
}