<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/14
 * Time: 16:41
 */
namespace app\admin\model;
use think\Model;
class UserRole extends Model{
    public function getRoleData($id){
        return $this->find($id);
    }
    public function getUserRoleList($is_ajax =0){
        $keywords = input("keywords") ? input("keywords") : '';
        $strip = input("strip") ? input("strip") : '10';
        $begintrade = input("begintrade") ? input("begintrade") : "";
        $endtrade = input("endtrade") ? input("endtrade") : '';

        $condition = 'l.is_del = 1';
        $condition .= " and l.role like '".'%'.$keywords.'%'."'";
        if($begintrade) $condition .= " and createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax == 1){

            return $this
                ->alias("l")
                ->field("l.*")
                ->where($condition)
                ->order("l.id desc")
                ->select();
        }

        return $this
            ->alias("l")
            ->field("l.*")
            ->where($condition)
            ->order("l.id desc")
            ->paginate($strip,false,['query'=>request()->param()]);
    }

    public function addRole($role = null){
        $data = [];
        $data['createtime'] = date('Y-m-d H:i:s',time());
        if($role){
            $data['role'] = $role;
        }else{
            return ShowMsg("请填写角色名称",0);
        }

        $data_role = $this->field("*")->where("role='".$role."' and is_del=1")->find();
        if($data_role){
            return ShowMsg("已有该角色名称",0);
        }else {
            $res = $this->insert($data);
            if ($res !== false) {
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
    }

    public function editRoleData($id,$role = null){
        $data = [];
        if($role){
            $data['role'] = $role;
        }else{
            return ShowMsg("请填写角色名称",0);
        }
        $data_role = $this->field("*")->where("role='".$role."'  and id<>'".$id."' and is_del=1 ")->find();
        if($data_role){
            return ShowMsg("已有该角色名称",0);
        }else{
            $res = $this -> where("id",$id) -> update($data);
            if($res !== false){
                return ShowMsg("成功",1);
            }else{
                return ShowMsg("失败",0);
            }
        }
    }

    public function delRole($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }






}