<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/16
 * Time: 13:53
 */
namespace app\admin\model;
use think\Model;
class Works extends Model{
    public function getWorksList($is_ajax = NULL){
        $title = input("title") ? input("title") : "";
        $class_id = input("class_id") ? input("class_id") : "";
        $begintrade = input("begintrade") ? input("begintrade") : "";
        $endtrade = input("endtrade") ? input("endtrade") : "";
        $strip = input("strip") ? input("strip") : "10";

        $condition = 'a.is_del = 1';
        if($title){
            $condition .= " and a.$title like '".'%'.$title.'%'."'";
        }
        if($class_id){
            $condition .= " and a.class_id ='".$class_id."'";
        }
        if($begintrade) $condition .= " and a.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and a.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax){
            return $this->alias("a")
                ->join("user ad","a.user_id=ad.id")
                ->join("works_type at","a.class_id=at.id")
                ->field("a.*,ad.username,ad.nickname,at.name")
                ->where($condition)
                ->order("id desc")
                ->select();
        }
        return $this->alias("a")
            ->join("user ad","a.user_id=ad.id")
            ->join("works_type at","a.class_id=at.id")
            ->field("a.*,ad.username,ad.nickname,at.name")
            ->where($condition)
            ->order("id desc")
            ->paginate($strip,false,['query' => request()->param()]);
    }
    public function delWorks($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 获取网站作品总数
     */
    public function getWorksNum(){
        return $this->count();
    }

}