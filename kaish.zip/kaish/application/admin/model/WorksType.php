<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/10/25
 * Time: 15:43
 */
namespace app\admin\model;
use think\Model;
class WorksType extends Model{
    public function getWorksTypeList($is_ajax = NULL){
        $name = input("name") ? input("name") : "";
        $begintrade = input("begintrade") ? input("begintrade") : "";
        $endtrade = input("endtrade") ? input("endtrade") : "";
        $strip = input("strip") ? input("strip") : "10";
        $condition = [
            'is_del'=>1,
            'name' => array('like','%'.$name.'%'),
        ];
        if($begintrade) $condition .= " and a.createtime >='".$begintrade."'";
        if($endtrade) $condition .= " and a.createtime <= '".date('Y-m-d H:i:s',strtotime($endtrade)+60*60*24)."'";

        if($is_ajax){
            return $this
                ->where($condition)
                ->order("id desc")
                ->select();
        }
        return $this
            ->where($condition)
            ->order("id desc")
            ->paginate($strip,false,['query' => request()->param()]);
    }
    public function delWorksType($id){
        if(is_array($id)){
            $res = $this->where("id","in",$id)->update(['is_del'=>0]);
        }else{
            $res = $this->where("id",$id)->update(['is_del'=>0]);
        }
        if($res !== false){
            return true;
        }else{
            return false;
        }
    }
    public function getWorksTypeListByLevel($level = '1'){
        return $this->where('level',$level)->select();
    }
}