<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
use think\Db;
use phpmailer\PHPMailer;
use think\Request;
use think\Loader;

//返货数据
function ShowMsg($msg,$code = 0,$data = []){
    $rs = ['code'=>$code,'msg'=>$msg];
    if(!empty($data))$rs['data'] = $data;
    return $rs;
}

/**
 * 执行钩子
 * Powered by: 李松大帅哥
 * @param $class
 * @param $tag
 * @param null $params
 * @return array|mixed
 */
function runHook($class, $tag, $params = null){
    $result=array();
    try {
        $result= \think\Hook::exec("org\\".$class, $tag, $params);
    } catch (\Exception $e) {
        $result["code"]=-1;
        $result["message"]="请求失败!";
    }
    return $result;
}

/**
 * 获取服务器信息
 * @return array
 */
function get_server_info()
{
    return array(
        '操作系统' => PHP_OS,
        '运行环境' => $_SERVER["SERVER_SOFTWARE"],
        'PHP运行方式' => php_sapi_name(),
        'PHP版本' => PHP_VERSION,
        '上传附件限制' => ini_get('upload_max_filesize'),
        '执行时间限制' => ini_get('max_execution_time') . '秒',
        '服务器时间' => date("Y年n月j日 H:i:s"),
        '北京时间' => gmdate("Y年n月j日 H:i:s", time() + 8 * 3600),
        '服务器域名/IP' => $_SERVER['SERVER_NAME'] . ' / ' . gethostbyname($_SERVER['SERVER_NAME']),
        '剩余空间' => 00 . 'M',
        'register_globals' => get_cfg_var("register_globals") == "1" ? "ON" : "OFF",
        'magic_quotes_gpc' => (1 === get_magic_quotes_gpc()) ? 'YES' : 'NO',
        'magic_quotes_runtime' => (1 === get_magic_quotes_runtime()) ? 'YES' : 'NO',
    );
}

//后台日志记录
function execAdminLog()
{
    $url = Request::instance()->controller() . '/' . Request::instance()->action();
    $admin_log = \think\Db::name('admin_log')->where([
        'admin_id' => session("admin_user.id"),
        'create_time' => ['between', [date("Y-m-d", time()) . ' 00:00:00', date("Y-m-d", time()) . ' 23:59:59']],
        'url' => $url,
    ])->find();
    if ($admin_log) {
        \think\Db::name('admin_log')->where(['id'=>$admin_log['id']])->update(array(
            'number' => $admin_log['number'] + 1,
        ));
    } else {
        \think\Db::name('admin_log')->insert(array(
            'admin_id' => session("admin_user.id"),
            'url' => $url,
            'mark' => $_SESSION['think']['auth_array'][$url],
            'create_time' => date("Y-m-d H:i:s", time()),
            'ip' => request()->ip(),
        ));
    }
}


/**
 * 获取配置信息
 * @param string $k 配置名字
 * @param string $getAll 是否得到整条记录
 * @return array|false|PDOStatement|string|\think\Model
 */
function get_conf($k , $getAll = ''){
    $config = new \app\admin\model\Config();
    if($getAll){
        return $config->where("k",$k)->find();
    }else{
        return $config->where("k",$k)->value('v_zh');
    }
}

/**
 * @param string $dir 文件夹名字
 * @return int|string 文件大小
 */
function getDirSize($dir)
{
    $sizeResult = 0;
    $handle = opendir($dir);

    while (false !== $FolderOrFile = readdir($handle)) {
        if (($FolderOrFile != '.') && ($FolderOrFile != '..')) {
            if (is_dir($dir . '/' . $FolderOrFile)) {
                $sizeResult += intval(getDirSize($dir . '/' . $FolderOrFile));
            }
            else {
                $sizeResult += intval(filesize($dir . '/' . $FolderOrFile));
            }
        }
    }
    closedir($handle);
    return getRealSize($sizeResult);
}

/**
 * 单位自动转换函数
 * @param $size
 * @return string
 */
function getRealSize($size)
{
    $kb = 1024;   // Kilobyte
    $mb = 1024 * $kb; // Megabyte
    $gb = 1024 * $mb; // Gigabyte
    $tb = 1024 * $gb; // Terabyte
    if($size < $kb)
    {
        return $size." B";
    }
    else if($size < $mb)
    {
        return round($size/$kb,2)." KB";
    }
    else if($size < $gb)
    {
        return round($size/$mb,2)." MB";
    }
    else if($size < $tb)
    {
        return round($size/$gb,2)." GB";
    }
    else
    {
        return round($size/$tb,2)." TB";
    }
}

/**
 * 递归的删除文件夹
 * @param string $dir 文件夹名字
 * @return bool 结果
 */
function deldir($dir) {
    //先删除目录下的文件：
    $dh=opendir($dir);
    while ($file=readdir($dh)) {
        if($file!="." && $file!="..") {
            $fullpath=$dir."/".$file;
            if(!is_dir($fullpath)) {
                unlink($fullpath);
            } else {
                deldir($fullpath);
            }
        }
    }
    closedir($dh);
    //删除当前文件夹：
    if(rmdir($dir)) {
        return true;
    } else {
        return false;
    }
}



/**
 * 去掉小数后面的0，整数的话要去掉.
 * Powered by: 李松大帅哥
 * @param $arg
 * @return string
 */
function delZero($arg){
    return rtrim(rtrim($arg,'0'),'.');
}

/**
 * 返回本月和上月的起止时间戳
 * Powered by: 李松大帅哥
 * @return mixed
 */
function get_time(){
    //本月起止时间戳
    $data['this_month_start'] = mktime(0,0,0,date('m'),1,date('Y'));
    $data['this_month_end'] = mktime(23,59,59,date('m'),date('t'),date('Y'));
    //上月起止时间戳
    $this_month = date('m');
    $this_year = date('Y');
    if ($this_month == 1) {
        $last_month = 12;
        $last_year = $this_year - 1;
    } else {
        $last_month = $this_month - 1;
        $last_year = $this_year;
    }
    $data['last_month_start'] = mktime(0,0,0,$last_month,1,$last_year);
    $data['last_month_end'] = mktime(23,59,59,$last_month,date('t',$data['last_month_start']),date('Y'));
    return $data;
}

function base64_upload($base64) {
    $base64_image = str_replace(' ', '+', $base64);
    //post的数据里面，加号会被替换为空格，需要重新替换回来，如果不是post的数据，则注释掉这一行
    if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image, $result)){
        //匹配成功
        if($result[2] == 'jpeg'){
            $image_name = uniqid().'.jpg';
            //纯粹是看jpeg不爽才替换的
        }else{
            $image_name = uniqid().'.'.$result[2];
        }
        $image_file = "./upload/auth/{$image_name}";
        //服务器文件存储路径
        if (file_put_contents($image_file, base64_decode(str_replace($result[1], '', $base64_image)))){
            return "/upload/auth/{$image_name}";
        }else{
            return false;
        }
    }else{
        return $base64;
    }
}

//导出
function exportExcel($title,$header,$data){

    Loader::import('phpexcel.PHPExcel.IOFactory');
    $objPHPExcel = new \PHPExcel();
    // 设置excel文档的属性
    $objPHPExcel->getProperties()->setCreator("Willie")//创建人
    ->setLastModifiedBy("Willie")//最后修改人
    ->setTitle(date('YmdHis'))//标题
    ->setSubject(date('YmdHis'))//题目
    ->setDescription(date('YmdHis'))//描述
    ->setKeywords(date('YmdHis'))//关键字
    ->setCategory("Test result file");//种类

    // 开始操作excel表
    $objPHPExcel->setActiveSheetIndex(0);
    // 设置工作薄名称
    $objPHPExcel->getActiveSheet()->setTitle(iconv('gbk', 'utf-8', 'Sheet'));
    // 设置默认字体和大小
    $objPHPExcel->getDefaultStyle()->getFont()->setName(iconv('gbk', 'utf-8', ''));
    $objPHPExcel->getDefaultStyle()->getFont()->setSize(11);

    $headerNum = count($header);
    $dataNum = count($data);

    $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');

    $objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$headerNum-1].'1');

    $objPHPExcel->setActiveSheetIndex(0)->setCellValueExplicit('A1', $title,PHPExcel_Cell_DataType::TYPE_STRING);

    for($i=0;$i<$headerNum;$i++){
        $objPHPExcel->setActiveSheetIndex(0)->setCellValueExplicit($cellName[$i].'2', $header[$i][1],PHPExcel_Cell_DataType::TYPE_STRING);
        if(isset($header[$i][2])){
            $objPHPExcel->getActiveSheet()->getColumnDimension($cellName[$i])->setWidth($header[$i][2]);
        }else{
            $objPHPExcel->getActiveSheet()->getColumnDimension($cellName[$i])->setWidth(15);
        }
    }
    //$objPHPExcel->getActiveSheet()->setCellValueExplicit('A1', '订单编号',PHPExcel_Cell_DataType::TYPE_STRING);

    for($i=0;$i<$dataNum;$i++){
        for($j=0;$j<$headerNum;$j++){
            $objPHPExcel->getActiveSheet(0)->setCellValueExplicit($cellName[$j].($i+3), $data[$i][$header[$j][0]],PHPExcel_Cell_DataType::TYPE_STRING);
        }
    }
//    for ($row = 0; $row < count($data); $row++){
//        $i = $row+2;
//        $objPHPExcel->getActiveSheet()->setCellValueExplicit('A'.$i, $data[$row]['id'],PHPExcel_Cell_DataType::TYPE_STRING);
//    }

    //输出EXCEL格式
    $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    ob_end_clean();//清除缓冲区,避免乱码
    // 从浏览器直接输出$filename
    header('Content-Type:application/csv;charset=UTF-8');
    header('cache-control:must-revalidate');
    header("Pragma: public");
    header("Expires: 0");
    //header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control:public");
    header("Content-Type:application/force-download");
    header("Content-Type:application/vnd.ms-excel;");
    header("Content-Type:application/octet-stream");
    header("Content-Type:application/download");
    header('Content-Disposition: attachment;filename="'.$title.date('YmdHis').'.xls"');
    header("Content-Transfer-Encoding:binary");
    $objWriter->save('php://output');
}