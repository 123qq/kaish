<?php
/**
 * 阿里云oss上传文件类
 * User: Administrator
 * Date: 2019/1/14
 * Time: 11:13
 */

//defined('IN_ECTOUCH') or die('Deny Access');
class AliyunOssController
{
    protected $accessKeyId = 'LTAIBfJoMGK90lWF';
    protected $accessKeySecret = 'KF1XNkmImdTGwNRtccDbJ909wkLu5w';
    protected $endpoint_inter = 'http://oss-cn-beijing-internal.aliyuncs.com';// 内网endpoint
    protected $endpoint_outer = 'http://oss-cn-beijing.aliyuncs.com';// 外网endpoint
    private $bucket = 'kaish';// 存储空间名称
    private $object = 'user/video/';// 文件名称
    private $ossClient;// 实例oss基类对象

    public function __construct()
    {
//        parent::__construct();
        if (is_file( ROOT_PATH.'include/bootstrap.php')) {
//            require_once ROOT_PATH.'include/bootstrap.php';
        }
        if (is_file(ROOT_PATH.'data/aliyun-oss/autoload.php')) {
            require_once ROOT_PATH.'data/aliyun-oss/autoload.php';
            require_once ROOT_PATH.'data/aliyun-oss/src/OSS/OssClient.php';
            require_once ROOT_PATH.'data/aliyun-oss/src/OSS/Core/OssException.php';
        }else{
            echo json_encode(['status'=>'404','message'=>'OssClient class not found!']);exit;
        }

        $accessKeyId = $this->accessKeyId;
        $accessKeySecret = $this->accessKeySecret;
        $endpoint = $this->endpoint_outer;

        $ossClient = new \OssClient($accessKeyId, $accessKeySecret, $endpoint);
        $this->ossClient = $ossClient;
    }

    //创建存储空间
    public function ceate_file(){
        try {
            $res = $this->ossClient->createBucket($this->bucket);
        } catch (OssException $e) {
            print $e->getMessage();
        }
        return $res;
    }

    /**
     * 上传文件
     * @param $filePath string
     * @return string
     * @throws \OSS\Core\OssException
     */
    public function upload_file($filePath){
        if (!file_exists($filePath)) {
            return false;
        }
        $md5_url = $this->make_suffix($filePath);
        // 文件名称
        $object = $this->object.$md5_url;

        try {
            $res = $this->ossClient->uploadFile($this->bucket, $object, $filePath);
        } catch (OssException $e) {
            printf($e->getMessage());
        }
        return $res['info']['url'];
    }

    /**
     * 删除文件
     * @param $object 文件名称
     */
    public function delete_file(){
        try {
            $res = $this->ossClient->deleteObject($this->bucket, $this->object.'shangjia.png');
        } catch (OssException $e) {
            print $e->getMessage();
        }
        return $res;
    }

    public function md5_crypt(){
        return md5(time().rand(111,999));
    }

    // 检查图片后缀
    private function check_pic_suffix($pic){
        if (strpos($pic,'.jpg') !== false) {
            return '.jpg';
        }elseif (strpos($pic,'.png') !== false) {
            return '.png';
        }elseif (strpos($pic,'.gif') !== false) {
            return '.gif';
        }
    }

    private function make_suffix($pic){
        return $this->md5_crypt().$this->check_pic_suffix($pic);
    }
}