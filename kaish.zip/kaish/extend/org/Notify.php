<?php
/**
 * Created by PhpStorm.
 * User: 李松大帅哥
 * Date: 2017/11/10
 * Time: 12:01
 */
namespace org;
use think\Request;

/**
 * 回调类
 * 开发规范：方法的命名使用驼峰法（首字母小写）
 * Class Notify
 * @package app\admin\hook
 */
class Notify{
    public $adminLogApi;
    public function __construct()
    {
        $this->adminLogApi=new \app\admin\model\AdminLog();
    }

    /**
     * Powered by: 李松大帅哥
     * 管理员登录记录
     */
    public function adminLogin(){

        $admin_log = $this->adminLogApi->where([
            'admin_id' => session("admin_user.id"),
            'create_time' => ['between', [date("Y-m-d", time()) . ' 00:00:00', date("Y-m-d", time()) . ' 23:59:59']],
            'url' => "Auth/login",
        ])->find();
        if ($admin_log) {
            $this->adminLogApi->where(['id'=>$admin_log['id']])->update(array(
                'number' => $admin_log['number'] + 1,
            ));
        } else {
            $this->adminLogApi->insert(array(
                'admin_id' => session("admin_user.id"),
                'url' => "Auth/login",
                'mark' => "管理员登录",
                'create_time' => date("Y-m-d H:i:s", time()),
                'ip' => request()->ip(),
            ));
        }
    }
}